<template>
    <svg class="w-4 h-4 mr-2 rounded-full" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<rect y="0.279" style="fill:#F5F5F5;" width="512" height="170.48"/>
<rect y="341.241" style="fill:#FF4B55;" width="512" height="170.48"/>
<rect y="170.761" style="fill:#41479B;" width="512" height="170.48"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
</template>