<script>
export default {
    name: "SkillCategoryHeaderTableComponent"
}
</script>
<template>

            <thead class="text-l  text-gray-800 uppercase dark:text-gray-200">
            <tr >
                <th scope="col" class="px-6 border-top-radius py-3 bg-gray-200 shadow dark:bg-gray-600">
                    Categories
                </th>
            </tr>
            </thead>

</template>



<style scoped>
.border-top-radius{
    border-radius:  5px  5px  0 0 ;
}
</style>