function getItem(key:string){
    return localStorage.getItem(key);
}