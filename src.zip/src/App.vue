<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import FlowbiteSetup from './FlowbiteSetup.vue';
</script>

<template> 
  <FlowbiteSetup></FlowbiteSetup>
  <RouterView></RouterView>
</template>

<style scoped>
</style>
