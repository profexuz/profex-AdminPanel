export class LoginViewModel{
    phoneNumber: string="";
    password: string=""
}