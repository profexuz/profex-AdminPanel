export  class SkillViewModel{
    categoryId: Number = 0;
    description: string = "";
    title: string = "";
    createdAt: Date = new Date();
    updatedAt: Date = new Date();
    id: Number = 0;
}