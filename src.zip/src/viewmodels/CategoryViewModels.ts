export class CategoryViewModel{
    name: string = "";
    description: string = "";
    createdAt: Date = new Date();
    updatedAt: Date = new Date();
    id: Number = 0;
}