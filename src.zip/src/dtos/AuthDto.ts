export class LoginDtos
{
    phoneNumber: String = "";
    password: String = "";
}